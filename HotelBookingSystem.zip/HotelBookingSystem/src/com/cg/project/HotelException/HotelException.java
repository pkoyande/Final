package com.cg.project.HotelException;

public class HotelException extends Exception {
	
			
		public HotelException() {
			super();
			
		}

		public HotelException(String message, Throwable cause) {
			super(message, cause);
			
		}
		public HotelException(String message) {
			super(message);
			
		}

	}



